<!DOCTYPE html >
<html lang="fr">
<head>
    <meta charset="UFT-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!--<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>-->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap.bundle.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/fiche_restitution_et_reception2.js"></script>
</head>
<?php 
    extract ($_POST);
    extract ($_GET);
    include ('connectDB.php');

?>
<body>

  <div class="text-center" style="color: navy;">
    <p><h4>Fiche de Restitution/Reception</h4></p>
  </div>
    <br>
    <div class="container">
        <form id="form_fiche_restitution_et_reception" method="post">
            <h5 style="color: black;">Information Agent</h5>
            <?php
            if (isset($numrestitution)){

            $sql = "SELECT NumAgent, PrenomAgent, NomAgent, LibelleService, LibelleDirection,LibelleFonction,DateRestitution,DateReception
            FROM agent
            INNER JOIN service ON agent.NumServiceAgent = service.NumService 
            INNER JOIN direction ON direction.NumDirection = service.NumDirectionService
            INNER JOIN fonction ON agent.NumFonctionAgent=fonction.NumFonction
            INNER JOIN restitution ON restitution.NumAgentRestitution=agent.NumAgent
            WHERE NumRestitution  =" .$numrestitution;
        
        

            $result = mysqli_query($link, $sql) or die (mysqli_error($link)) ;
            $taille = mysqli_num_rows($result);
            if($taille > 0){ 

                $row = mysqli_fetch_assoc($result); ?>
                <h6 style="color: #2F4F4F;">Numéro agent :</h6>
                <?php echo '<input type="text" style="background-color:#F0F8FF; border:2px solid #F0F8FF; width: 450px;" value="'; if (isset($numrestitution)){
                    echo $row['NumAgent'];} else {echo ' ';} echo '" readonly>'; ?>
                    <div class="form-row">
                        <div class="form-group col-sm-6">
                            <label for="Nom">Nom :</label>
                    <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                        echo $row['NomAgent'];} else {echo ' ';} echo '" readonly>'; ?>
                        </div>
                        <div class="form-group col-sm-6">
                                <label for="Prénom">Prénom :</label>
                    <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                        echo $row['PrenomAgent'];} else {echo ' ';} echo '"readonly>'; ?>
                         </div>

                        <div class="form-group col-sm-6">
                        <label for="Fonction">Fonction :</label>
                    <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                        echo $row['LibelleFonction'];} else {echo ' ';} echo '"readonly>'; ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-sm-6">
                            <label for="Service">Service :</label>
                            <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                            echo $row['LibelleService'];} else {echo ' ';} echo '"readonly>'; ?>
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="Direction">Direction :</label>
                            <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                            echo $row['LibelleDirection'];} else {echo ' ';} echo '"readonly>'; ?>
                        </div>
                    </div>
                <?php echo '<input type="text" hidden name="NumAgent" value="'; if (isset($numrestitution)){
                    echo $row['NumAgent'];} else {echo ' ';} echo '" readonly>';?>
                     </br>
              
            <div class="form-row">
		        <div class="col-sm-12">
                    <div class="card">
                        <div class= "card-header text-center" style="font-weight:bold;">
                             Date de restitution et de réception du matériel
                        </div>
                            <div class="card-body ">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="DateRestitutinon">Date restitution :</label>   
                                        <?php echo '<input type="date" class="form-control" name= "daterestitution" value="' ;  if (isset($numrestitution)){
                                            echo $row['DateRestitution'];} else {echo date("Y-m-d");} echo '">'; ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                            <label for="DateReception">Date Réception :</label>   
                                                <?php echo '<input type="date" class="form-control" name= "datereception" value="' ;  if (isset($numrestitution)){
                                        echo $row['DateReception'];} else {echo date("Y-m-d");} echo '">'; ?>
                                    </div>
                                </div>
                            </div>
                    </div>  
                 </div>
            </div>             
           
        <?php
     
     mysqli_free_result($result);
                    }
            else{
                    echo "something wont wrong...";
                    }
            

        }
        ?>
        <br>
        </br>
         <h5>Identification du matériel</h5>
            <br>
            
        <div class="form-row">
                <div class="form-group col-sm-4">
                   <label for="Typemateriel">Type matériel :</label>
                   <br>
                        <?php  
                                $sql2 = "SELECT * FROM `materiel`";
                                $result2 = mysqli_query($link, $sql2) or die (mysqli_error($link)) ;
                                $taille2 = mysqli_num_rows($result2);
                        ?>
                                <select class="form-control custom-select" id="nummateriel" onchange="selection_materiel(this.value)">
                                <option value="0">--matériel--</option>
                        <?php   for ($i=0; $i < $taille2; $i++)
                                    {
                                        mysqli_data_seek($result2,$i);
                                        $row2 = mysqli_fetch_assoc($result2);
                                        echo '<option value="'. $row2['NumMateriel'].'">'.$row2['LibelleMateriel'].'</option>' ;
                                    }
                        ?>
                                </select>
                </div>   

                            <div class="form-group col-sm-4">
                            <label for="Modele">Modèle :</label>
                            <br>
                                    <?php   $sql3 = "SELECT * FROM `modele`";
                                            $result3 = mysqli_query($link, $sql3) or die (mysqli_error($link)) ;
                                            $taille3 = mysqli_num_rows($result3);
                                    ?>
                                
                                <select class="form-control custom-select" id="nummodele" >
                                <option value="modele">--modèle--</option>
                                    <?php   for ($i=0; $i < $taille3; $i++)
                                                {
                                                    mysqli_data_seek($result3,$i);
                                                    $row3 = mysqli_fetch_assoc($result3);
                                                    echo '<option value="'. $row3['NumModele'].'">'.$row3['LibelleModele'].'</option>' ;
                                                }
                                    ?>
                                </select>
                            </div>
                    <div class="form-group col-sm-4">
                        <label for="Constructeur">Constructeur/Opérateur :</label>
                            <br>
                                <?php   $sql4 = "SELECT * FROM `constructeur`";
                                $result4 = mysqli_query($link, $sql4) or die (mysqli_error($link)) ;
                                $taille4 = mysqli_num_rows($result4);
                                ?>
                            <select class="form-control custom-select" id="numconstructeur">
                                <option value="constructeur">--constructeur--</option>
                                    <?php   for ($i=0; $i < $taille4; $i++)
                                    {
                                        mysqli_data_seek($result4,$i);
                                        $row4 = mysqli_fetch_assoc($result4);
                                        echo '<option value="'. $row4['NumConstructeur'].'">'.$row4['LibelleConstructeur'].'</option>' ;
                                    }
                        ?>
                            </select>
                    </div>
        </div>
        <div class="form-row">
                <div class="form-group col-sm-4">
                    <label for="Numserie">N° série :</label>
                    <input class="form-control" type="text"  id="numserie" >
                </div>
 
                <div class="form-group col-sm-4">
                    <label for="Observation">Observation :</label>
                    <textarea id="observation" rows="10" cols="30" ></textarea>
                </div>
                <?php echo '<input type="text" hidden  id="numrestitution" value="'.$numrestitution.'">'; ?>
</div>


        <center>
            <button type="button" class="btn btn-outline-secondary" value="retour" name="retour" onclick="Javascript:window.document.location.href='Restitution_liste.php';" >retour</button>
            <button disabled type= "button" class="btn btn-primary" id="btn_ajouter_materiel" onclick="ajout_materiel()">Ajouter materiel</button>
        </center>
            <br>
            <br>
        

       <div id="list_materiels_restitues">
  <?php 
             include("view_list_materiels_restitues.php");
  ?>
       </div>
    </form>
</div>
</body>
</html>