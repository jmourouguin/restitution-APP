
  function ajout_materiel()
  {
               
                var numrestitution = $("#numrestitution").val();
                var nummateriel = $("#nummateriel").val();
                var nummodele = $("#nummodele").val();
                var numconstructeur = $("#numconstructeur").val();
                var numserie = $("#numserie").val();
                var observation = $("#observation").val();
                var action = "ajout_materiel";
                //alert("numrestitution: "+numrestitution);
                //alert("nummateriel: "+nummateriel);
                
                $.ajax
                ({
                url : "Action.php",
                data : "numrestitution="+numrestitution+"&nummateriel="+nummateriel+"&nummodele="+nummodele+"&numconstructeur="+numconstructeur+"&numserie="+numserie+"&observation"+observation+"&action="+action,
                method : "POST",
                success : function(resultat)
                               {            
                                             //alert(resultat);                          
                                             //view_message('<div class="alert alert-success text-center" role="alert">le matériel a été supprimé</div>');
                                             $("#list_materiels_restitues").html(resultat);
                               }
                });
                
            }

function delete_ligne_restitution_et_reception(i)
                    {
                                        
                                        var numrestitution = $("#numrestitution"+i).val();
                                        var nummateriel = $("#nummateriel"+i).val();
                                        var action = "del_ligne_restitution_et_reception";
                                        //alert("numrestitution: "+numrestitution);
                                        //alert("nummateriel: "+nummateriel);
                                        $.ajax
                                        ({
                                        url : "Action.php",
                                        data : "numrestitution="+numrestitution+"&nummateriel="+nummateriel+"&action="+action,
                                        method : "POST",
                                        success : function(resultat)
                                                        {            
                                                                    //alert(resultat);                          
                                                                    //view_message('<div class="alert alert-success text-center" role="alert">le matériel a été supprimé</div>');
                                                                    $("#list_materiels_restitues").html(resultat);
                                                        }
                                        });
                    
                                        
                                    }

function selection_materiel(nummateriel)
                            {
                                if (nummateriel > 0)
                                 {
                                       
                                    
                                     $("#btn_ajouter_materiel").removeProp('disabled','disabled');
                                        
                                }
                                else 
                                    {
                                        $("#nummodele").val(0);
                                        $("#numconstructeur").val(0);
                                        $("#numserie").val(' ');
                                        $("#observation").val(' ');
                                        $("#btn_ajouter_materiel").prop('disabled','disabled');
                                    }

                            }


