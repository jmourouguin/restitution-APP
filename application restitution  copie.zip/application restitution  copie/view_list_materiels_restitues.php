<?php
echo'
<table id="listmateriel" class="table table-border">
        <thead>
             <tr>
                <th class="col-sm-1 texte-center">
                    Type matériel</th>
                <th class="col-sm-1 texte-center">
                    Constructeur/Opérateur</th>
                <th class="col-sm-1 texte-center">
                    Modèles</th>
                 <th class="col-sm-1 texte-center">
                     N°Séries</th>
                <th class="col-sm-1 texte-center">
                     Observation</th>
                <th class="col-sm-1 texte-center">
                     </th>

            </tr>
        </thead>
            <tbody>';
             
                    $sql = "SELECT LibelleMateriel , LibelleModele , LibelleConstructeur , NumSerie , Observation, NumMateriel, NumRestitutionLigne
                    FROM lignematerielrestitution lmr
                    INNER JOIN materiel ON lmr.NumMaterielLigne  = materiel.NumMateriel  
                    INNER JOIN modele ON lmr.NumModeleLigne = modele.NumModele
                    INNER JOIN constructeur ON lmr.NumConstructeurLigne  = constructeur.NumConstructeur
                    WHERE NumRestitutionLigne =".$numrestitution;
                    
                    if($result = mysqli_query($link, $sql)) {

                        
                        $taille = mysqli_num_rows($result);

                    if($taille > 0){


                        for ($i=0; $i < $taille; $i++)
                        {
                            mysqli_data_seek($result,$i);
                            $row = mysqli_fetch_assoc($result);
                            echo '<tr>
                            <td>'. $row['LibelleMateriel']. '</td>
                            <td>'. $row['LibelleConstructeur']. '</td>
                            <td>'. $row['LibelleModele'].'</td>
                            <td> '. $row['NumSerie']. '</td>
                            <td> '. $row['Observation']. '</td>
                            <td>
                            <button class="btn btn-link" type="button" onclick="delete_ligne_restitution_et_reception('.$i.')">Suprimer</button>
                            <input type="text" hidden  id="numrestitution'.$i.'" value="'.$row["NumRestitutionLigne"].'">
                            <input type="text" hidden  id="nummateriel'.$i.'" value="'.$row["NumMateriel"].'">
                            </td>
                            </tr>' ; 

                        }

                            mysqli_free_result($result);
                        }
                        else{
                            echo "<tr><td colspan=5> AUCUNE DONNEES TROUVEES </td></tr>";
                        }
                    }
                    else {
                        "ERROR : Could not execute $sql." . mysqli_error($link);
                    }
?>