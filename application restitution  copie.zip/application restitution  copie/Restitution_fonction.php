<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #DDD;
}

tr:hover {background-color: #D6EEEE;}
</style>
</head>
<body>


<table style="width:100%">
  <tr>
    <th>N°Restitution</th>
    <th>N°Agent</th>
    <th>Prénom</th>
    <th>Nom</th>
    <th>Service</th>
    <th>Direction</th>
    <th>Date Restitution</th>
    <th>Date Reception</th>
    <th>+Ajouter fiche restitution/reception</th>
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</table>

</body>
</html>


