<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
<meta charset="utf-8" >
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="js/bootstrap.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #DDD;
}

tr:hover {background-color: #D6EEEE;}

<?php include ('connectDB.php'); ?>
</style>
</head>
<body>


            
<form action="restitution_fiche1.php" method="post">
<table class="table table-border">
  <thead>
  <tr>
    <th class="col-sm-1 texte-center">
      N°Restitution</th>
    <th class="col-sm-1 texte-center">
      N°Agent</th>
    <th class="col-sm-1 texte-center">
      Prénom</th>
    <th class="col-sm-1 texte-center">
      Nom</th>
    <th class="col-sm-2 texte-center">
      Service</th>
    <th class="col-sm-2 texte-center">
      Direction</th>
    <th class="col-sm-1 texte-center">
      Date Restitution</th>
    <th class="col-sm-1texte-center">
      Date Reception</th>

    <th colspan="2"class="col-sm-2 texte-center">
      <button class="btn btn-primary" type="submit" name="AjouterFiche">+Ajouter Fiche Restitution/Réception</button></th>
</tr>
</thead>
<tbody>
  <?php
        $sql = "SELECT NumAgent, PrenomAgent, NomAgent, LibelleService, LibelleDirection,NumRestitution,DateRestitution,DateReception
        FROM agent
        INNER JOIN service ON agent.NumServiceAgent = service.NumService 
        INNER JOIN direction ON direction.NumDirection = service.NumDirectionService
        INNER JOIN restitution ON agent.NumAgent = restitution.NumAgentRestitution";
        
        if($result = mysqli_query($link, $sql)) {

            
            $taille = mysqli_num_rows($result);

           if($taille > 0){


            for ($i=0; $i < $taille; $i++)
            {
                mysqli_data_seek($result,$i);
                $row = mysqli_fetch_assoc($result);
                echo '<tr>
                <td>'. $row['NumRestitution']. '</td>
                <td>'. $row['NumAgent']. '</td>
                <td>'. $row['PrenomAgent'].'</td>
                <td> '. $row['NomAgent']. '</td>
                <td> '. $row['LibelleService']. '</td>
                <td> '. $row['LibelleDirection']. '</td>
                <td>'. $row['DateRestitution']. '</td>
                <td>'. $row['DateReception']. '</td>
                <td><a  href="Restitution_fiche2.php?numrestitution='.$row['NumRestitution'].'">modifier</a></td>
                <td class="text-center"><a  href="Action.php?action=deleterestitution&numrestitution='.$row['NumRestitution'].'">supprimer</a></td>
                </tr>' ;

             }

                mysqli_free_result($result);
            }
            else{
                echo "something wont wrong...";
            }
        }
        else {
            "ERROR : Could not execute $sql." . mysqli_error($link);
        }
    ?>
</tbody>
</table>
</form>

</body>
</html>


