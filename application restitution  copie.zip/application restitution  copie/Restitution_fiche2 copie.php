<!DOCTYPE html >
<html lang="fr">
<head>
    <meta charset="UFT-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
    <!--<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>-->
<!--<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap.bundle.js"></script>-->
    
</head>
<?php 
    extract ($_POST);
    extract ($_GET);
    include ('connectDB.php');

?>
<body>

  <div class="text-center" style="color: navy;">
    <p><h4>Fiche de Restitution/Reception</h4></p>
  </div>
    <br>
    <div class="container">
        <form id="form_fiche_restitution_et_reception" method="post">
        <h5 style="color: black;">Information Agent</h5>
        <?php
        if (isset($numrestitution)){

        $sql = "SELECT NumAgent, PrenomAgent, NomAgent, LibelleService, LibelleDirection,LibelleFonction,DateRestitution,DateReception
        FROM agent
        INNER JOIN service ON agent.NumServiceAgent = service.NumService 
        INNER JOIN direction ON direction.NumDirection = service.NumDirectionService
        INNER JOIN fonction ON agent.NumFonctionAgent=fonction.NumFonction
        INNER JOIN restitution ON restitution.NumAgentRestitution=agent.NumAgent
        WHERE NumRestitution  =" .$numrestitution;
        
        

            $result = mysqli_query($link, $sql) or die (mysqli_error($link)) ;
            $taille = mysqli_num_rows($result);
            if($taille > 0){ 

                $row = mysqli_fetch_assoc($result); ?>
                <h6 style="color: #2F4F4F;">Numéro agent :</h6>
                <?php echo '<input type="text" style="background-color:#F0F8FF; border:2px solid #F0F8FF; width: 450px;" value="'; if (isset($numrestitution)){
                    echo $row['NumAgent'];} else {echo ' ';} echo '" readonly>'; ?>
                    <div class="form-row">
                        <div class="form-group col-sm-6">
                            <label for="Nom">Nom :</label>
                    <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                        echo $row['NomAgent'];} else {echo ' ';} echo '" readonly>'; ?>
                        </div>
                        <div class="form-group col-sm-6">
                                <label for="Prénom">Prénom :</label>
                    <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                        echo $row['PrenomAgent'];} else {echo ' ';} echo '"readonly>'; ?>
                         </div>

                        <div class="form-group col-sm-6">
                        <label for="Fonction">Fonction :</label>
                    <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                        echo $row['LibelleFonction'];} else {echo ' ';} echo '"readonly>'; ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-sm-6">
                            <label for="Service">Service :</label>
                            <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                            echo $row['LibelleService'];} else {echo ' ';} echo '"readonly>'; ?>
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="Direction">Direction :</label>
                            <?php echo '<input type="text" class="form-control" value="'; if (isset($numrestitution)){
                            echo $row['LibelleDirection'];} else {echo ' ';} echo '"readonly>'; ?>
                        </div>
                    </div>
                <?php echo '<input type="text" hidden style="background-color:#F0F8FF; border:2px solid #F0F8FF; width: 450px;" name="NumAgent" value="'; if (isset($numrestitution)){
                    echo $row['NumAgent'];} else {echo ' ';} echo '" readonly>'; ?>
               </br>

             <div class="card">
                <div class= "card-header text-center">
                    Date de restitution et de réception du matériel
                </div>
                <div class="card-body ">
                    <div class="form-row">
                        <div class="form-group col-sm-6">
                                <label for="DateRestitutinon">Date restitution :</label>   
                            <?php echo '<input type="date" style="background-color:#F0F8FF; border:2px solid #F0F8FF; width: 450px;" name= "daterestitution" value="' ;  if (isset($numrestitution)){
                                echo $row['DateRestitution'];} else {echo ' ';} echo '"'; ?>
                        </div>
                        <div class="form-group col-sm-6">
                                <label for="DateRéception">Date Réception :</label>   
                                    <?php echo '<input type="date" style="background-color:#F0F8FF; border:2px solid #F0F8FF; width: 450px;" name= "datereception" value="' ;  if (isset($numrestitution)){
                            echo $row['DateReception'];} else {echo ' ';} echo '"'; ?>
                        </div>
                    </div>
                </div>
            </div>  
                                    </br>            
            
                                            
                    
                

        <?php
                mysqli_free_result($result);
                    }
            else{
                    echo "something wont wrong...";
                    }
            

        }
        ?>
        
        <font size="5pt"><h3>Identification du matériel </font>
            <br>
            <div class="form-row">
                <div class="form-group col-sm-4">
                   <label for="Typemateriel">Type matériel :</label>
            
            <?php   $sql2 = "SELECT * FROM `materiel`";
                    $result2 = mysqli_query($link, $sql2) or die (mysqli_error($link)) ;
                    $taille2 = mysqli_num_rows($result2);
            ?>
                    <select id="materiel" name="materiel" size="1"  style= "border:1px solid #000000; width: 250px;" required>
                    <option value="materiel">--matériel--</option>
            <?php   for ($i=0; $i < $taille2; $i++)
                        {
                            mysqli_data_seek($result2,$i);
                            $row2 = mysqli_fetch_assoc($result2);
                            echo '<option value="'. $row2['NumMateriel'].'">'.$row2['LibelleMateriel'].'</option>' ;
                        }
            ?>
                    </select>
                </div>   

                <div class="form-group col-sm-4">
                   <label for="Modele">Modèle :</label>
            <?php   $sql3 = "SELECT * FROM `modele`";
                    $result3 = mysqli_query($link, $sql3) or die (mysqli_error($link)) ;
                    $taille3 = mysqli_num_rows($result3);
            ?>
                    <select id="modele" name="modele" size="1"  style= "border:1px solid #000000; width: 250px;" required>
                    <option value="modele">--modèle--</option>
            <?php   for ($i=0; $i < $taille3; $i++)
                        {
                            mysqli_data_seek($result3,$i);
                            $row3 = mysqli_fetch_assoc($result3);
                            echo '<option value="'. $row3['NumModele'].'">'.$row3['LibelleModele'].'</option>' ;
                        }
            ?>
                    </select>
                </div>
                <div class="form-group col-sm-4">
                    <label for="Constructeur">Constructeur/Opérateur :</label>
             <?php   $sql4 = "SELECT * FROM `constructeur`";
                    $result4 = mysqli_query($link, $sql4) or die (mysqli_error($link)) ;
                    $taille4 = mysqli_num_rows($result4);
            ?>
                    <select id="constructeur" name="constructeur" size="1"  style= "border:1px solid #000000; width: 250px;" required>
                    <option value="constructeur">--constructeur--</option>
            <?php   for ($i=0; $i < $taille4; $i++)
                        {
                            mysqli_data_seek($result4,$i);
                            $row4 = mysqli_fetch_assoc($result4);
                            echo '<option value="'. $row4['NumConstructeur'].'">'.$row4['LibelleConstructeur'].'</option>' ;
                        }
            ?>
                    </select>
                </div>
             </div>
             <div class="form-row">
                <div class="form-group col-sm-4">
                    <label for="Numserie">N° série :</label>
                    <input type="text" style="border:1px solid #000000; width: 250px;" name = "numserie" >
                </div>
                <div class="form-group col-sm-4">
                    <label for="Observation">Observation :</label>
                    <textarea name="observation" rows="10" cols="30" ></textarea>
                </div>
                <?php echo '<input type="text" hidden style="background-color:#F0F8FF; border:2px solid #F0F8FF; width: 450px;" name="numrestitution" value="'.$numrestitution.'"'; ?>
             </div>

            <center><font size="10pt"><input type="button" value="retour" name="retour" onclick="Javascript:window.document.location.href='Restitution_liste.php';" >
            <input type="submit" value="Ajouter Matériel"  name = "ajoutermateriel">
            <br>
            <br>
        

        <table id="listmateriel" class="table table-border">
        <thead>
             <tr>
                <th class="col-sm-1 texte-center">
                    Type matériel</th>
                <th class="col-sm-1 texte-center">
                    Constructeur/Opérateur</th>
                <th class="col-sm-1 texte-center">
                    Modèles</th>
                 <th class="col-sm-1 texte-center">
                     N°Séries</th>
                <th class="col-sm-1 texte-center">
                     Observation</th>
            </tr>
        </thead>
            <tbody>
                <?php
                    $sql = "SELECT LibelleMateriel , LibelleModele , LibelleConstructeur , NumSerie , Observation
                    FROM lignematerielrestitution lmr
                    INNER JOIN materiel ON lmr.NumMaterielLigne  = materiel.NumMateriel  
                    INNER JOIN modele ON lmr.NumModeleLigne = modele.NumModele
                    INNER JOIN constructeur ON lmr.NumConstructeurLigne  = constructeur.NumConstructeur
                    WHERE NumRestitutionLigne =".$numrestitution;
                    
                    if($result = mysqli_query($link, $sql)) {

                        
                        $taille = mysqli_num_rows($result);

                    if($taille > 0){


                        for ($i=0; $i < $taille; $i++)
                        {
                            mysqli_data_seek($result,$i);
                            $row = mysqli_fetch_assoc($result);
                            echo '<tr>
                            <td>'. $row['LibelleMateriel']. '</td>
                            <td>'. $row['LibelleConstructeur']. '</td>
                            <td>'. $row['LibelleModele'].'</td>
                            <td> '. $row['NumSerie']. '</td>
                            <td> '. $row['Observation']. '</td>
                            </tr>' ; 

                        }

                            mysqli_free_result($result);
                        }
                        else{
                            echo "<tr><td colspan=5> AUCUNE DONNEES TROUVEES </td></tr>";
                        }
                    }
                    else {
                        "ERROR : Could not execute $sql." . mysqli_error($link);
                    }
                ?>
             </tbody>
        </table>

        </form>
    </div>
</body>
</html> 